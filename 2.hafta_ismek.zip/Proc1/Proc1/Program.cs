﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proc1
{
    class Program
    {
        static void Main(string[] args)
        {
            #region hesap makinesi switch-case
            //Console.Write("1.Sayıyı giriniz= ");
            //int s1 = int.Parse(Console.ReadLine());
            //Console.Write("2.Sayıyı giriniz= ");
            //int s2 = int.Parse(Console.ReadLine());
            //Console.WriteLine("Yapmak istediğiniz işlemi giriniz:\n Toplam=+ \n Çıkartma=- \n Çarpma=* \n Bölme=/ ");
            //char secim = Convert.ToChar(Console.ReadLine());
            //double sonuc;
            //switch (secim)
            //{
            //    case '+':
            //        sonuc = s1 + s2;
            //        Console.WriteLine("Sonuç={0}", sonuc);
            //        break;
            //    case '-':
            //        sonuc = s1 - s2;
            //        Console.WriteLine("Sonuç={0}", sonuc);
            //        break;
            //    case '*':
            //        sonuc = s1 * s2;
            //        Console.WriteLine("Sonuç={0}", sonuc);
            //        break;
            //    case '/':
            //        sonuc = s1 / s2;
            //        Console.WriteLine("Sonuç={0}", sonuc);
            //        break;
            //}
            //Console.Read();
            #endregion
            #region tam bölünür bölünmez if-else
            //Console.Write("1.Sayıyı giriniz= ");
            //double s1 = double.Parse(Console.ReadLine());
            //Console.Write("2.Sayıyı giriniz= ");
            //double s2 = double.Parse(Console.ReadLine());
            //if (s1 > s2)
            //{
            //    if (s1 % s2 == 0)
            //    {
            //        Console.WriteLine("Tam Bölünür");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Tam Bölünmez");
            //    }
            //}
            //else if (s1==s2)
            //{
            //    Console.WriteLine("Girilen sayılar eşit");
            //}
            //else
            //{
            //    if (s2 % s1 == 0)
            //    {
            //        Console.WriteLine("Tam Bölünür");
            //    }
            //    else
            //    {
            //        Console.WriteLine("Tam Bölünmez");
            //    }
            //}
            //Console.Read();
            #endregion
            #region örn3 Hesap Makinesi yapma if-else
            //Console.Write("1.Sayıyı giriniz= ");
            //double s1 = double.Parse(Console.ReadLine());
            //Console.Write("2.Sayıyı giriniz= ");
            //double s2 = double.Parse(Console.ReadLine());
            //Console.WriteLine("Yapmak istediğiniz işlemi giriniz:\n Toplam=+ \n Çıkartma=- \n Çarpma=* \n Bölme=/ ");
            //char secim = Convert.ToChar(Console.ReadLine());
            //double sum;
            //if (secim=='+')
            //{
            //    sum=s1 + s2;
            //    Console.WriteLine("Sonuç={0}",sum);
            //}
            //else if (secim=='-')
            //{
            //    sum = s1 - s2;
            //    Console.WriteLine("Sonuç={0}", sum);
            //}
            //else if (secim == '*')
            //{
            //    sum = s1 * s2;
            //    Console.WriteLine("Sonuç={0}", sum);
            //}
            //else if (secim == '/')
            //{
            //    sum = s1 / s2;
            //    Console.WriteLine("Sonuç={0}", sum);
            //}
            //else
            //{
            //    Console.WriteLine("Hatalı giriş yaptınız lütfen tekrar deneyiniz.");
            //}
            //Console.Read();
            #endregion
            #region sayıları kıyaslama:if-else

            //int s1= Convert.ToInt32(Console.ReadLine());
            //int s2= Convert.ToInt32(Console.ReadLine());
            //if (s1>s2)
            //{
            //    Console.WriteLine("{0} sayısı {1} sayısından büyüktür.",s1,s2);
            //}
            //else if (s2>s1)
            //{
            //    Console.WriteLine("{0} sayısı {1} sayısından büyüktür.", s2, s1);

            //}
            //else
            //{
            //    Console.WriteLine("Sayılar birbirine eşittir.");
            //}
            //Console.Read();
            #endregion
            #region Vücut Kitle İndeksi hesasaplama: if-else
            //Console.Write("Boyunuzu giriniz=");
            //double boy = double.Parse(Console.ReadLine());
            //Console.Write("Kilonuzu giriniz=");
            //double Kilo = double.Parse(Console.ReadLine());
            //double vki = Kilo / (boy * boy);
            //if (vki > 0 && vki<18)
            //{
            //    Console.WriteLine("Vücüt Kitle indeksiniz={0} Zayıf",vki);
            //}
            //else if (vki >= 19 && vki <=25)
            //{
            //    Console.WriteLine("Vücüt Kitle indeksiniz={0} Normal",vki);
            //}
            //else if (vki >= 25 && vki <= 29)
            //{
            //    Console.WriteLine("Vücüt Kitle indeksiniz={0} Fazla Kilolu",vki);
            //}
            //else if (vki >= 30)
            //{
            //    Console.WriteLine("Vücüt Kitle indeksiniz={0} Obez",vki);
            //}
            //else
            //{
            //    Console.WriteLine("Hatalı giriş yaptınız lütfen tekrar deneyiniz");
            //}
            //Console.Read();
            #endregion
            #region Katı-sıvı-gaz:if-else
            //Console.Write("Sicaklık değeri giriniz= ");
            //double sicaklik = double.Parse(Console.ReadLine());
            //if (sicaklik>100)
            //{
            //    Console.WriteLine("GAZ");
            //}
            //else if (sicaklik<0)
            //{
            //    Console.WriteLine("KATI");
            //}
            //else
            //{
            //    Console.WriteLine("SIVI");
            //}
            //Console.Read();
            #endregion
            #region Maaş hesaplama
            //Console.Write("Maaşınızı giriniz:");
            //double maas = double.Parse(Console.ReadLine());
            //Console.Write("Çocuk sayısını giriniz:");
            //double evlat = double.Parse(Console.ReadLine());
            //Console.Write("İşlenen parça sayısını giriniz giriniz:");
            //double parca = double.Parse(Console.ReadLine());
            //double maas1;
            //if (evlat == 1)
            //{
            //    maas1 = maas*0.05;
            //}
            //else if (evlat == 2)
            //{
            //    maas1 = maas * 0.10;
            //}
            //else if (evlat > 3)
            //{
            //    maas1 = maas * 0.15;
            //}
            //else
            //{
            //    maas1 = maas;
            //}
            //double maas2=0;
            //if (50<parca &&parca<100)
            //{
            //    maas2 = maas * 0.10;
            //}
            //else if (100 < parca && parca < 150)
            //{
            //    maas2 = maas * 0.15;
            //}
            //else if (150 <=parca)
            //{
            //    maas2 = maas * 0.20;
            //}
            //double maas3 = maas + maas1 + maas2;

            //Console.WriteLine("Maaşınız={0}",maas3);
            //Console.Read();

            #endregion
            #region ***Bilgi Yarışması***
            //Console.Write("İsminizi Lütfen giriniz:");
            //string name = Console.ReadLine();
            //Console.WriteLine("Yarışmaya Hoşgeldin {0}",name);
            //int puan = 0;


            //Console.WriteLine("Soru1:Türkiye'nin başkenti Neresidir?");
            //string c1 = Console.ReadLine();
            //string c12 = c1.ToUpper();
            //if (c1=="ANKARA"||c12=="ANKARA")
            //{
            //    puan += 10;

            //    Console.WriteLine("Soru2:En kalabalık ilimiz hangisidir?");
            //    string c2 = Console.ReadLine();
            //    if (c2=="İstanbul"||c2=="istanbul"||c2=="İSTANBUL")
            //    {
            //        puan += 10;

            //        Console.WriteLine("Soru3:Cumhuriyet Kaç yılında ilan edilmiştir?");
            //        string c3 = Console.ReadLine();
            //        if (c3=="1923")
            //        {
            //            puan += 10;
            //        }
            //    }
            //}
            //if (puan==30)
            //{
            //    Console.WriteLine("Tebrikler sayın {0} Yarışmayı kazandınız.",name);
            //}
            //else
            //{
            //    Console.WriteLine("sayın {0} Yarışmayı {1}Puan ile yarışmayı tamamladınız", name,puan);
            //}
            //Console.Read();
            #endregion
            #region üçgen çeşidi belirtme :if-else-1
            //Console.Write("1. açınızı giriniz:");
            //double a1 = double.Parse(Console.ReadLine());
            //Console.Write("2. açınızı giriniz:");
            //double a2 = double.Parse(Console.ReadLine());
            //Console.Write("3. açınızı giriniz:");
            //double a3 = double.Parse(Console.ReadLine());
            //if ((a1==a2 && a1==a3 && a2==a3) && (a1 + a2 + a3) == 180)
            //{
            //    Console.WriteLine("Eşkenar Üçgen");
            //}
            //else if ((a1==a2||a1==a3 ||a2==a3) && (a1 + a2 + a3) == 180)
            //{
            //    Console.WriteLine("İkizkenar üçgen");
            //}
            //else if ((a1 + a2 + a3)==180)
            //{
            //    Console.WriteLine("Eskenar Üçgen");
            //}
            //else if ((a1+a2+a3)!=180)
            //{
            //    Console.WriteLine("Hatalı giriş yaptınız tekrar deneyin");
            //}
            //Console.Read();
            #endregion
            #region ücgen cesidi belirtme:if-else-2
            //Console.Write("1. açınızı giriniz:");
            //double a1 = double.Parse(Console.ReadLine());
            //Console.Write("2. açınızı giriniz:");
            //double a2 = double.Parse(Console.ReadLine());
            //Console.Write("3. açınızı giriniz:");
            //double a3 = double.Parse(Console.ReadLine());
            //if (((a1 + a2 + a3) == 180)&&(a1!=0 && a2 != 0&& a3 != 0))
            //{
            //    if (a1 == a2 && a2 == a3)
            //    {
            //        Console.WriteLine("Eşkenar Üçgen");
            //    }
            //    else if ((a1 == a2 || a1 == a3 || a2 == a3))
            //    {
            //        Console.WriteLine("İkizkenar üçgen");
            //    }
            //    else if ((a1 + a2 + a3) == 180)
            //    {
            //        Console.WriteLine("Eskenar Üçgen");
            //    }
            //}
            //else
            //{
            //    Console.WriteLine("Hatalı giriş yaptınız tekrar deneyin");
            //}
            //Console.Read();
            #endregion
            #region Ay isimleri: if-else
            //Console.Write("Sayı giriniz:");
            //int m1 = int.Parse(Console.ReadLine());
            //if (m1==1)
            //{
            //    Console.WriteLine("Ocak");
            //}
            //else if (m1==2)
            //{
            //    Console.WriteLine("Şubat");
            //}
            //else if (m1 == 3)
            //{
            //    Console.WriteLine("Mart");
            //}
            //else if (m1 == 4)
            //{
            //    Console.WriteLine("Nisan");
            //}
            //else if (m1 == 5)
            //{
            //    Console.WriteLine("Mayıs");
            //}
            //else if (m1 == 6)
            //{
            //    Console.WriteLine("Haziran");
            //}
            //else if (m1 == 7)
            //{
            //    Console.WriteLine("Temmuz");
            //}
            //else if (m1 == 8)
            //{
            //    Console.WriteLine("Ağustos");
            //}
            //else if (m1 == 9)
            //{
            //    Console.WriteLine("Eylül");
            //}
            //else if (m1 == 10)
            //{
            //    Console.WriteLine("Ekim");
            //}
            //else if (m1 == 11)
            //{
            //    Console.WriteLine("Kasım");
            //}
            //else if (m1 == 12)
            //{
            //    Console.WriteLine("Aralık");
            //}
            //else
            //{
            //    Console.WriteLine("Hatalı giriş yaptınız");
            //}
            //Console.Write("{0}.Ay", m1);
            //Console.Read();
            #endregion
            #region Ay isimleri: switch-case
            //Console.Write("SAYİ GİRİNİZ:");
            //    int aylar = int.Parse(Console.ReadLine());
            //switch (aylar)
            //{
            //    case 1: Console.WriteLine("OCAK");break;
            //    case 2: Console.WriteLine("ŞUBAT"); break;
            //    case 3: Console.WriteLine("MART"); break;
            //    case 4: Console.WriteLine("NİSAN"); break;
            //    case 5: Console.WriteLine("MAYIS"); break;
            //    case 6: Console.WriteLine("HAZİRAN"); break;
            //    case 7: Console.WriteLine("TEMMUZ"); break;
            //    case 8: Console.WriteLine("AĞUSTOS"); break;
            //    case 9: Console.WriteLine("EYLÜL"); break;
            //    case 10: Console.WriteLine("EKİM"); break;
            //    case 11: Console.WriteLine("KASIM"); break;
            //    case 12: Console.WriteLine("ARALIK"); break;
            //    default: Console.WriteLine("HATALI GİRİŞ"); break;
            //}
            //Console.Read();
            #endregion
            #region Girilen aya göre mevsim:switch-case

            //Console.WriteLine("Hangi Aydasınız?");
            //string aylar = Console.ReadLine();
            //string aylarupper = aylar.ToUpper();
            //switch (aylarupper)
            //{
            //    case "OCAK": Console.WriteLine("Kış Ayındasınız."); break;
            //    case "ŞUBAT": Console.WriteLine("Kış Ayındasınız."); break;
            //    case "MART": Console.WriteLine("İlkbahar Ayındasınız."); break;
            //    case "NİSAN": Console.WriteLine("İlkbahar Ayındasınız."); break;
            //    case "MAYIS": Console.WriteLine("İlkbahar Ayındasınız."); break;
            //    case "HAZİRAN": Console.WriteLine("İlkbahar Ayındasınız."); break;
            //    case "TEMMUZ": Console.WriteLine("Yaz Ayındasınız."); break;
            //    case "AĞUSTOS": Console.WriteLine("Yaz Ayındasınız."); break;
            //    case "EYLÜL": Console.WriteLine("Sonbahar Ayındasınız."); break;
            //    case "EKİM": Console.WriteLine("Sonbahar Ayındasınız."); break;
            //    case "KASIM": Console.WriteLine("Sonbahar Ayındasınız."); break;
            //    case "ARALIK": Console.WriteLine("Kış Ayındasınız."); break;
            //    default: Console.WriteLine("Hatalı giriş"); break;
            //}
            //Console.Read();

            #endregion
            #region Sorular:switch-case

            Console.WriteLine("Halk edebiyatındaki koşmanın konu bakımından Divan edebiyatındaki benzeri aşağıdakilerden hangisidir ?\nA) Güzelleme\nB) Şarkı\nC) Kaside\nD) Gazel\nE) Muhammes");
            string cevap = Convert.ToString(Console.ReadLine());
            string cevaptoupper = cevap.ToUpper();
            switch (cevaptoupper)
            {
                case "A":
                case "B":
                case "C":
                case "E":
                Console.WriteLine("Yanlış");
                break;
                case "D": Console.WriteLine("Bu dizelerdeki söz sanatı aşağıdakilerden hangisidir?\n\nA) İntak\nB) Tezat\nC) Teşbih\nD) Telmih\nE) Tevriye");
                    string cevap2 = Convert.ToString(Console.ReadLine());
                    string cevap2toupper = cevap2.ToUpper();
                         switch (cevap2toupper)
                        {
                            case "A":
                            case "B":
                            case "D":
                            case "E":
                            Console.WriteLine("Yanlış");
                            break;
                            case "C": Console.WriteLine("TEBRİKLER"); break;
                            default: Console.WriteLine("Hatalı İşlem"); break;
                        }
                    break;

                default:break;

            }
            Console.Read();

            #endregion
            #region Ödev

            #endregion
        }
    }
}
