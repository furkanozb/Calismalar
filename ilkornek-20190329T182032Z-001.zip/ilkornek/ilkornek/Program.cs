﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ilkornek
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.write--> Siyah ekranda yazma işlemi yapar.
            /*     Açıklama satırının birden satır için geçerli hali.     */

            /* Console.Write("merhaba dünya");
             Console.WriteLine("merhaba dünya");*/

            //  Console.Write("c# dersleri");







            /* Console.Write("Özlem ");
             Console.WriteLine("ANI");
             Console.Write("       ");
             Console.Write("C# ");
             Console.WriteLine("Dersleri");
             Console.WriteLine("Öğreniyorum");

         */



            //  Console.WriteLine("3+5="+(3+5));

            /////////////////////////////////////////////
            /*  string kelime = "merhaba dünya";
              Console.WriteLine(kelime);*/
            ////////////////////////////////////////////////////
            /* double sayi1 =10;
             double sayi2 = 8;
             double toplam =sayi1+sayi2;
             double carpim = sayi1 * sayi2;
             double bolum = sayi1 / sayi2;
            double fark = sayi1 - sayi2;

             Console.WriteLine("sayıların toplamı="+toplam);
             Console.WriteLine("sayıların çarpımı=" + carpim);
             Console.WriteLine("sayıların bölümü=" + bolum);
             Console.WriteLine("sayıların farkı=" + fark);


             char karakter = 's';
             Console.WriteLine(karakter);

             bool varmi = true;
             Console.WriteLine(varmi);

             varmi = false;
             Console.WriteLine(varmi);


     */






            /* Console.Write("İsminizi giriniz.");
             string isim = Console.ReadLine();





             Console.Write("Soyİsminizi giriniz.");
             string soyisim = Console.ReadLine();


             Console.Write("Yaşınızı giriniz.");
             //  int yas=Convert.ToInt32( Console.ReadLine());
             int yas = int.Parse(Console.ReadLine());
             //int.parse -- Convert.ToInt32--> işlemleri değişkenleri int türüne çevirme işlemi yapar.
             //Console.ReadLine()--> klavyeden deger çekme işlemi yapar.
             Console.Write("Hoşgeldiniz. "+isim+" "+soyisim+" Yaşınız:"+yas);
             */







            /*  double ortalama,not1,not2,not3;
              string isim, soyisim;
              Console.Write("İsminizi giriniz.");
              isim = Console.ReadLine();

              Console.Write("Soyisminizi giriniz.");
              soyisim = Console.ReadLine();



              Console.Write("1. Notu giriniz.");
            not1 = double.Parse(Console.ReadLine());

              Console.Write("2. Notu giriniz.");
             not2 = double.Parse(Console.ReadLine());

              Console.Write("3. Notu giriniz.");
           not3 = double.Parse(Console.ReadLine());


              ortalama = (not1 + not2 + not3) / 3;


              Console.WriteLine(isim+" "+soyisim+" isimli öğrencinnin ortalaması="+ortalama);
              Console.WriteLine("{0} {2} isimli öğrencinin ortalaması={1}",isim,soyisim,ortalama);
              Console.WriteLine($"{isim} {soyisim} isimli öğrencinin ortalaması={ortalama}");











      */










            /*  Console.WriteLine("Sayı giriniz");
              double sayi1 = double.Parse(Console.ReadLine());



              Console.WriteLine("Sayı giriniz");
              double sayi2 = double.Parse(Console.ReadLine());

              double toplama, cikarma, carpma, bolme, kalan, yuzde;


              toplama = sayi1 + sayi2;
              cikarma = sayi1 - sayi2;
              carpma = sayi1 * sayi2;
              bolme = sayi1 / sayi2;
              kalan = sayi1 % sayi2;
              yuzde = sayi1 * sayi2 / 100;

              Console.WriteLine($"{sayi1} ile {sayi2} nin toplamı={toplama} ");
              Console.WriteLine($"{sayi1} ile {sayi2} nin farkı={cikarma} ");
              Console.WriteLine($"{sayi1} ile {sayi2} nin çarpımı={carpma} ");
              Console.WriteLine($"{sayi1} ile {sayi2} nin bölümü={bolme} ");
              Console.WriteLine($"{sayi1}in {sayi2}ye bölümünden kalan={kalan} ");
              Console.WriteLine($"{sayi1} in {sayi2} ye göre yüzdesi={yuzde} ");
              */



            // const  string isim="özlem";
            // Console.WriteLine(isim);
            // değişkenin başına const eklendiginde değişkeni sabitler.









            /*  Console.WriteLine("Yarıçap giriniz.");
              double yaricap = double.Parse(Console.ReadLine());

              const double pi = 3.14;

              double alan = pi * yaricap * yaricap;
              double cevre = 2 * pi * yaricap;

              Console.WriteLine($"Yarıçapı {yaricap} olan dairenin alanı = {alan}");
              Console.WriteLine($"Yarıçapı {yaricap} olan dairenin çevresi = {cevre}");
              */








            //  İki iç açısı verilen üçgenin diğer açısını bulan algoritma ve programı tasarlayın. 
            // a+b+c=180


            /* Console.WriteLine("1. iç açıyı giriniz.");
             int aci1 = int.Parse(Console.ReadLine());

             Console.WriteLine("2. iç açıyı giriniz.");
             int aci2 = int.Parse(Console.ReadLine());


             int aci3 = 180 - (aci1 + aci2);




             Console.WriteLine($"1. Acı:{aci1}");
             Console.WriteLine($"2. Acı:{aci2}");
             Console.WriteLine($"3. Acı:{aci3}");
             */







            //Dik kenar uzunlukları verilen dik üçgende hipotenüs hesaplayan algoritma ve programı tasarlayın.

            /*  Console.WriteLine("İlk kenarı giriniz.");
              double kenar1 = double.Parse(Console.ReadLine());
              Console.WriteLine("İkinci kenarı giriniz.");
              double kenar2 = double.Parse(Console.ReadLine());

              double hipotenuskare = (kenar1 * kenar1) + (kenar2 * kenar2);
              double hipotenus = Math.Sqrt(hipotenuskare);
              //    double hipotenus = Math.Sqrt((kenar1 * kenar1) + (kenar2 * kenar2));

              Console.WriteLine($"kenar1: {kenar1}");
              Console.WriteLine($"kenar2: {kenar2}");
              Console.WriteLine($"kenar3: {hipotenus}");

      */







            //Kullanıcı tarafından girilen üç basamaklı sayının birler, onlar ve yüzler basamağına ayıran algoritma ve programı yazın.

            /* Console.WriteLine("Sayı giriniz.");
             double sayi = double.Parse(Console.ReadLine());




          double birler = sayi % 10;

             Console.WriteLine("Birler Basamagı="+birler);


             double onlar = ((sayi - birler)/10)%10;
             double onlar2 = ((sayi - birler)%100)/10;

             Console.WriteLine("Onlar2 Basamagı=" + onlar2);
             Console.WriteLine("Onlar Basamagı=" + onlar);




             double yuzler =(sayi- (sayi % 100))/100;
                        Console.WriteLine("Yüzler Basamagı=" + yuzler);



     */


            /*  Console.WriteLine("Merhaba\nbenim adım özlem    ");
              // \n--> yazıldıgı yerden sonra bir alt satıra geçiş işlemi yapar.
              Console.WriteLine("Merhaba benim adım:\tÖzlem");
              // \t --> yazıldıgı yere tab tuşu kadar boşluk bırakır.
              Console.WriteLine("Benim adım:\r özlem");
              // \r --> yazıldıgı yerden sonraki karakter sayısı kadar baştan silerek yerine kelimeyi yazar.
              Console.WriteLine("Merhaba benim adım:\aÖzlem");
              Console.WriteLine("\a");
              // \a--> bip sesi çıkartır.



      */






            // Console.WriteLine("\\merhaba dünya \\");
            // Console.WriteLine("\"merhaba dünya\"");
            // (\,") gibi özel karakterlerin siyah ekranda görünmesini istiyorsak başına ters slaş \ konulur.




            //   if ()//koşul yazılır.
            //    { }// eğer bu koşul dogru ise bu kısım çalışır.
            //else { }// eğer koşul yanlış ise bu kısım.

            /* int sayi = int.Parse(Console.ReadLine()) ;

             if (sayi==5)
             {
                 Console.WriteLine("Sayı 5tir.");
             }
             else
             {
                 Console.WriteLine("Sayı 5ten farklıdır.");
             }

     */



            //Klavyeden yaşı girilen kişinin ehliyet alıp alamayacağını belirten  programı yazınız.
            /*  Console.WriteLine("Yaşınızı giriniz.");
              int yas = int.Parse(Console.ReadLine());

              if (yas>17)
              {
                  Console.WriteLine("Ehliyet alabilirsiniz.");
              }
              else
              {
                  Console.WriteLine("Ehliyet alamazsınız.");
              }

      */


            /*  Console.WriteLine("Sayı giriniz.  ");
              int sayi = int.Parse(Console.ReadLine());
              bool citfmitekmi = sayi % 2 == 0 ? true:false ;
             if (sayi%2==0)
               {
                  citfmitekmi = true;
               }
               else
               {
                  citfmitekmi = false;

               }


         /*     if (sayi==sayi/2*2)
              {
                  Console.WriteLine("çifttir.");
              }
              else
              {
                  Console.WriteLine("tektir.");
              }


      */




            Console.WriteLine("Not1 giriniz");
            int not1 = int.Parse(Console.ReadLine());


            if (not1>=0)
            {
                //sadece 0dan büyük sayılar.
       
                if (not1 <= 100)
                {
                    //0-100 arasındaki sayılar


                    Console.WriteLine("Not2 giriniz");
                    int not2 = int.Parse(Console.ReadLine());

                    if (not2>=0 && not2<=100 )
                    {
                        Console.WriteLine("Final giriniz");
                        int final = int.Parse(Console.ReadLine());

                        if(final >= 0 && final <= 100)
                           {
                            int ortalama = ((not1 + not2) * 30 + final * 40) / 100;
                            Console.WriteLine("Ortalamanız" + ortalama);

                            if (ortalama >= 50)
                            {

                                Console.WriteLine("Geçti");
                            }
                            else
                            {

                                Console.WriteLine("Kaldı");
                            }



                        }
                        else
                        {
                            Console.WriteLine("yanlış değer girişi");
                        }
                    }
                    else
                    {
                        Console.WriteLine("yanlış değer girişi");
                    }

                }
                else
                {
                    Console.WriteLine("yanlış değer girişi");
             
                }

            }
            else
            {
                Console.WriteLine("yanlış değer girişi");

            }













           






            Console.ReadKey();





           


        }
    }
}
